describe("grunt-maven failing test", function() {
    it("should fail", function() {
        expect(true).toBe(true);
    });
});